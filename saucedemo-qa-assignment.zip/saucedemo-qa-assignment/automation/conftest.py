"""
Shared pytest fixtures for the SauceDemo Selenium suite.

Uses webdriver-manager so nobody has to hand-install a matching
chromedriver binary. Run headed by default; pass --headless via
env var HEADLESS=1 for CI.
"""
import os
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager


@pytest.fixture
def driver():
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    # Common CI hardening flags; harmless locally.
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    if os.environ.get("HEADLESS", "0") == "1":
        options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")

    service = Service(ChromeDriverManager().install())
    drv = webdriver.Chrome(service=service, options=options)

    yield drv

    drv.quit()


@pytest.fixture
def standard_user_driver(driver):
    """Driver that's already logged in as standard_user, for tests that
    don't need to exercise the login flow itself."""
    from pages.login_page import LoginPage

    LoginPage(driver).load().login("standard_user", "secret_sauce")
    return driver
