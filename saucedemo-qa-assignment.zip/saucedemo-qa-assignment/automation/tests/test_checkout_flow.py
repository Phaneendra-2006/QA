"""
TC-03: Add item to cart and complete checkout end-to-end (standard_user)

Also asserts the order-math invariant: item_total + tax == total,
which is the kind of check that catches BUG-level rounding issues
even though this flow is expected to pass for standard_user.
"""
import math
import pytest
from pages.inventory_page import InventoryPage
from pages.cart_and_checkout_page import (
    CartPage,
    CheckoutStepOnePage,
    CheckoutStepTwoPage,
    CheckoutCompletePage,
)


@pytest.mark.critical
def test_add_to_cart_and_complete_checkout(standard_user_driver):
    driver = standard_user_driver
    inventory_page = InventoryPage(driver)

    inventory_page.add_backpack_to_cart()
    assert inventory_page.get_cart_badge_count() == 1, "Badge should show 1 after adding one item"

    inventory_page.go_to_cart()
    cart_page = CartPage(driver)
    assert cart_page.get_item_count() == 1, "Cart page should list exactly the 1 item added"

    cart_page.go_to_checkout()
    CheckoutStepOnePage(driver).fill_info(
        first_name="Jane", last_name="Doe", postal_code="94107"
    ).continue_to_overview()

    step_two = CheckoutStepTwoPage(driver)
    item_total = step_two.get_item_total()
    tax = step_two.get_tax()
    total = step_two.get_total()

    assert math.isclose(item_total + tax, total, abs_tol=0.01), (
        f"Order math mismatch: {item_total} + {tax} != {total}"
    )

    step_two.finish()

    complete_page = CheckoutCompletePage(driver)
    confirmation = complete_page.get_confirmation_text()
    assert "thank you for your order" in confirmation.lower()


def test_checkout_step_one_requires_last_name(standard_user_driver):
    """TC-04-style negative check: leaving Last Name blank must block progress."""
    driver = standard_user_driver
    InventoryPage(driver).add_backpack_to_cart().go_to_cart()
    CartPage(driver).go_to_checkout()

    step_one = CheckoutStepOnePage(driver)
    step_one.fill_info(first_name="Jane", last_name="", postal_code="94107")
    step_one.continue_to_overview()

    error_text = step_one.text_of(step_one.ERROR_MESSAGE).lower()
    assert "last name" in error_text
    assert "checkout-step-two.html" not in driver.current_url
