"""
TC-02 (dedicated file, per assignment requirement #3):
Login with locked_out_user must fail with a specific, user-facing error
message, and must never establish a session.
"""
import pytest
from pages.login_page import LoginPage


@pytest.mark.critical
def test_locked_out_user_cannot_log_in(driver):
    login_page = LoginPage(driver).load()
    login_page.login("locked_out_user", "secret_sauce")

    assert login_page.is_on_login_page()
    assert "inventory.html" not in driver.current_url

    error_text = login_page.get_error_text()
    assert error_text == "Epic sadface: Sorry, this user has been locked out.", (
        f"Unexpected error copy: {error_text!r}"
    )


def test_locked_out_user_cannot_bypass_via_direct_url(driver):
    """Even if login is rejected, hitting the inventory URL directly must
    not be accepted as a valid session."""
    login_page = LoginPage(driver).load()
    login_page.login("locked_out_user", "secret_sauce")

    driver.get("https://www.saucedemo.com/inventory.html")
    assert "inventory.html" not in driver.current_url or login_page.is_on_login_page()
