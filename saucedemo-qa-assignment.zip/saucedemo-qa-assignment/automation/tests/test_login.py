"""
TC-01: Successful login with a valid user (standard_user)
TC-02: Login is blocked for locked_out_user with the correct error message
"""
import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage

VALID_PASSWORD = "secret_sauce"


@pytest.mark.critical
def test_login_with_valid_credentials(driver):
    login_page = LoginPage(driver).load()
    login_page.login("standard_user", VALID_PASSWORD)

    inventory_page = InventoryPage(driver)
    assert inventory_page.is_loaded(), "Expected to land on the Products page after login"
    assert "inventory.html" in driver.current_url
    assert inventory_page.get_item_count() == 6, "Expected 6 products in the catalog"


@pytest.mark.critical
def test_login_locked_out_user_shows_error(driver):
    login_page = LoginPage(driver).load()
    login_page.login("locked_out_user", VALID_PASSWORD)

    assert login_page.is_on_login_page(), "locked_out_user must not reach the inventory page"
    error_text = login_page.get_error_text()
    assert "locked out" in error_text.lower(), (
        f"Expected a 'locked out' error message, got: {error_text!r}"
    )
    assert "inventory.html" not in driver.current_url


def test_login_with_invalid_password_shows_generic_error(driver):
    login_page = LoginPage(driver).load()
    login_page.login("standard_user", "wrong_password")

    assert login_page.is_on_login_page()
    error_text = login_page.get_error_text().lower()
    assert "username and password do not match" in error_text
