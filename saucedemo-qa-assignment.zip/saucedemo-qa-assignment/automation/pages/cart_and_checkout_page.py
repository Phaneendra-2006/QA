from selenium.webdriver.common.by import By
from .base_page import BasePage


class CartPage(BasePage):
    CHECKOUT_BUTTON = (By.CSS_SELECTOR, "[data-test='checkout']")
    CART_ITEM = (By.CSS_SELECTOR, ".cart_item")

    def get_item_count(self) -> int:
        return len(self.find_all(self.CART_ITEM))

    def go_to_checkout(self):
        self.click(self.CHECKOUT_BUTTON)
        return self


class CheckoutStepOnePage(BasePage):
    FIRST_NAME = (By.CSS_SELECTOR, "[data-test='firstName']")
    LAST_NAME = (By.CSS_SELECTOR, "[data-test='lastName']")
    POSTAL_CODE = (By.CSS_SELECTOR, "[data-test='postalCode']")
    CONTINUE_BUTTON = (By.CSS_SELECTOR, "[data-test='continue']")
    ERROR_MESSAGE = (By.CSS_SELECTOR, "[data-test='error']")

    def fill_info(self, first_name: str, last_name: str, postal_code: str):
        self.type_into(self.FIRST_NAME, first_name)
        self.type_into(self.LAST_NAME, last_name)
        self.type_into(self.POSTAL_CODE, postal_code)
        return self

    def continue_to_overview(self):
        self.click(self.CONTINUE_BUTTON)
        return self


class CheckoutStepTwoPage(BasePage):
    ITEM_TOTAL = (By.CSS_SELECTOR, "[data-test='subtotal-label']")
    TAX = (By.CSS_SELECTOR, "[data-test='tax-label']")
    TOTAL = (By.CSS_SELECTOR, "[data-test='total-label']")
    FINISH_BUTTON = (By.CSS_SELECTOR, "[data-test='finish']")

    @staticmethod
    def _parse_dollar_amount(label_text: str) -> float:
        # Labels look like "Item total: $29.99" — extract the numeric part.
        return float(label_text.split("$")[-1])

    def get_item_total(self) -> float:
        return self._parse_dollar_amount(self.text_of(self.ITEM_TOTAL))

    def get_tax(self) -> float:
        return self._parse_dollar_amount(self.text_of(self.TAX))

    def get_total(self) -> float:
        return self._parse_dollar_amount(self.text_of(self.TOTAL))

    def finish(self):
        self.click(self.FINISH_BUTTON)
        return self


class CheckoutCompletePage(BasePage):
    COMPLETE_HEADER = (By.CSS_SELECTOR, ".complete-header")

    def get_confirmation_text(self) -> str:
        return self.text_of(self.COMPLETE_HEADER)
