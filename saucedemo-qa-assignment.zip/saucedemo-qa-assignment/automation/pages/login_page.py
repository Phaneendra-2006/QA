from selenium.webdriver.common.by import By
from .base_page import BasePage

BASE_URL = "https://www.saucedemo.com/"


class LoginPage(BasePage):
    # Stable selectors: SauceDemo exposes data-test attributes specifically
    # so automation doesn't have to rely on brittle CSS classes or text.
    USERNAME_INPUT = (By.CSS_SELECTOR, "[data-test='username']")
    PASSWORD_INPUT = (By.CSS_SELECTOR, "[data-test='password']")
    LOGIN_BUTTON = (By.CSS_SELECTOR, "[data-test='login-button']")
    ERROR_MESSAGE = (By.CSS_SELECTOR, "[data-test='error']")

    def load(self):
        self.driver.get(BASE_URL)
        return self

    def login(self, username: str, password: str):
        self.type_into(self.USERNAME_INPUT, username)
        self.type_into(self.PASSWORD_INPUT, password)
        self.click(self.LOGIN_BUTTON)
        return self

    def get_error_text(self) -> str:
        return self.text_of(self.ERROR_MESSAGE)

    def is_on_login_page(self) -> bool:
        return self.is_visible(self.LOGIN_BUTTON)
