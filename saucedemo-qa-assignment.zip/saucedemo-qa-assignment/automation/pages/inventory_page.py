from selenium.webdriver.common.by import By
from .base_page import BasePage


class InventoryPage(BasePage):
    PAGE_TITLE = (By.CSS_SELECTOR, ".title")
    INVENTORY_ITEM = (By.CSS_SELECTOR, ".inventory_item")
    CART_BADGE = (By.CSS_SELECTOR, "[data-test='shopping-cart-badge']")
    CART_LINK = (By.CSS_SELECTOR, "[data-test='shopping-cart-link']")

    @staticmethod
    def add_to_cart_selector(item_test_id: str):
        return (By.CSS_SELECTOR, f"[data-test='add-to-cart-{item_test_id}']")

    ADD_BACKPACK_TO_CART = (By.CSS_SELECTOR, "[data-test='add-to-cart-sauce-labs-backpack']")

    def is_loaded(self) -> bool:
        return self.text_of(self.PAGE_TITLE).strip().lower() == "products"

    def add_backpack_to_cart(self):
        self.click(self.ADD_BACKPACK_TO_CART)
        return self

    def get_cart_badge_count(self) -> int:
        if not self.is_visible(self.CART_BADGE):
            return 0
        return int(self.text_of(self.CART_BADGE))

    def go_to_cart(self):
        self.click(self.CART_LINK)
        return self

    def get_item_count(self) -> int:
        return len(self.find_all(self.INVENTORY_ITEM))
