"""Shared base class for all Page Objects.

Centralizes explicit-wait helpers so individual page objects never call
time.sleep() and never touch the driver directly for waits. This keeps
selectors and wait strategy consistent and makes the suite resilient to
SauceDemo's normal render timing (and to performance_glitch_user's
artificial delay).
"""
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

DEFAULT_TIMEOUT = 10
# performance_glitch_user intentionally delays rendering; give it more room.
GLITCH_USER_TIMEOUT = 20


class BasePage:
    def __init__(self, driver, timeout: int = DEFAULT_TIMEOUT):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def find(self, locator):
        return self.wait.until(EC.presence_of_element_located(locator))

    def find_clickable(self, locator):
        return self.wait.until(EC.element_to_be_clickable(locator))

    def find_all(self, locator):
        return self.wait.until(EC.presence_of_all_elements_located(locator))

    def is_visible(self, locator) -> bool:
        try:
            return self.wait.until(EC.visibility_of_element_located(locator)).is_displayed()
        except Exception:
            return False

    def text_of(self, locator) -> str:
        return self.find(locator).text

    def click(self, locator):
        self.find_clickable(locator).click()

    def type_into(self, locator, text: str):
        el = self.find_clickable(locator)
        el.clear()
        el.send_keys(text)
